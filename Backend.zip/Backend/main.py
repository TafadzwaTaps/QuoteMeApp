from datetime import datetime, timedelta
import os
import uuid
import shutil
import mimetypes
import mimetypes
import logging
import re
import time
from collections import defaultdict
from threading import Lock

from fastapi import FastAPI, HTTPException, Depends, Header, File, Response, UploadFile, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer


from supabase import create_client
from jose import jwt, JWTError
from passlib.context import CryptContext

# =========================
# CONFIG
# =========================
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
UPLOAD_DIR = "./uploads"
STATIC_DIR = "./static"
FRONTEND_HTML = "index.html"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)

SECRET_KEY = os.getenv("SECRET_KEY", "!QuoteMe_ZW@2026")
ALGORITHM = "HS256"
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif"}
MAX_UPLOAD_BYTES = 8 * 1024 * 1024  # 8 MB

# Supabase Storage bucket — create in Dashboard: Storage → New bucket → "images" → Public ON
SUPABASE_BUCKET = os.getenv("SUPABASE_BUCKET", "images")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# =========================
# SIMPLE IN-MEMORY RATE LIMITER
# =========================
_rate_store: dict = defaultdict(list)
_rate_lock = Lock()

def _rate_limit(key: str, max_calls: int, window_seconds: int):
    """
    Raise HTTP 429 if `key` has exceeded `max_calls` within `window_seconds`.
    Thread-safe. Uses sliding window.
    """
    now = time.time()
    with _rate_lock:
        calls = _rate_store[key]
        # Prune old entries
        calls[:] = [t for t in calls if now - t < window_seconds]
        if len(calls) >= max_calls:
            raise HTTPException(
                status_code=429,
                detail=f"Too many requests. Please wait a moment and try again. 🙏"
            )
        calls.append(now)

def _client_ip(request: Request) -> str:
    """Extract client IP, respecting reverse-proxy headers."""
    xff = request.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip()
    return request.client.host if request.client else "unknown"

# =========================
# APP
# =========================
app = FastAPI(title="QuoteMe Supabase API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    """Add security headers to every response and handle HEAD requests."""
    if request.method == "HEAD":
        response = await call_next(request)
        return Response(
            content=None,
            status_code=response.status_code,
            headers=response.headers,
            media_type=response.media_type,
        )
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    return response

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


@app.get("/")
def home():
    return FileResponse("static/index.html")

@app.get("/admin")
def admin_page():
    return FileResponse("static/admin.html")

@app.get("/dashboard")
def dashboard_page():
    return FileResponse("static/dashboard.html")

@app.get("/story/{story_id}")
def story_page(story_id: int):
    return FileResponse("static/story.html")

@app.get("/privacy")
def privacy_page():
    return FileResponse("static/privacy.html")

@app.get("/terms")
def terms_page():
    # Serve privacy page as placeholder if terms page not yet created
    import os as _os
    if _os.path.exists("static/terms.html"):
        return FileResponse("static/terms.html")
    return FileResponse("static/privacy.html")

# =========================
# AUTH HELPERS
# =========================
def verify_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("username")
        # Check expiry is present
        if not username or "exp" not in payload:
            return None
        return username
    except JWTError:
        return None
    except Exception:
        return None


def require_admin(authorization: str = Header(...)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid authorization header")
    token = authorization[7:]  # strip "Bearer "
    user = verify_token(token)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized — invalid or expired token")
    return user

def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("username")
        if not username:
            raise HTTPException(status_code=401, detail="Invalid token")
        return {"username": username}
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

def _verify_user_token(token: str) -> dict | None:
    """Verify a site-user JWT and return the payload dict, or None if invalid."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("type") != "user" or "user_id" not in payload:
            return None
        return {
            "id":        payload["user_id"],
            "username":  payload["username"],
            "email":     payload.get("email", ""),
            "is_banned": payload.get("is_banned", 0),
        }
    except (JWTError, Exception):
        return None

def _make_user_token(user: dict) -> str:
    """Create a JWT for an authenticated site user (12-hour expiry)."""
    expire = datetime.utcnow() + timedelta(hours=12)
    return jwt.encode({
        "type":      "user",
        "user_id":   user["id"],
        "username":  user["username"],
        "email":     user["email"],
        "is_banned": user.get("is_banned", 0),
        "exp":       expire,
    }, SECRET_KEY, algorithm=ALGORITHM)

# =========================
# INPUT SANITIZATION
# =========================
def _strip_html(text: str) -> str:
    """Remove HTML tags from user-provided strings."""
    return re.sub(r'<[^>]+>', '', text or '').strip()

def _validate_str(value, field: str, max_len: int = 1000, required: bool = True) -> str:
    if not value and required:
        raise HTTPException(status_code=400, detail=f"{field} is required")
    cleaned = _strip_html(str(value or ''))
    if len(cleaned) > max_len:
        raise HTTPException(status_code=400, detail=f"{field} exceeds maximum length of {max_len} characters")
    return cleaned

# ==============================
# 💬 SENTIMENT
# ==============================
POS = {"love","great","amazing","wonderful","inspiring","beautiful","excellent","fantastic","awesome","good","brilliant","perfect","happy","joy","thank","best","outstanding"}
NEG = {"hate","terrible","awful","bad","horrible","worst","ugly","boring","disappointing","sad","angry","useless","poor","disgusting","failed","wrong"}

def sentiment(text):
    words = set(text.lower().split())
    if len(words & POS) > len(words & NEG):
        return "positive"
    elif len(words & NEG) > len(words & POS):
        return "negative"
    return "neutral"


# =========================
# ADMIN LOGIN
# =========================
@app.post("/admin/login")
def admin_login(data: dict, request: Request):
    # Rate limit: 10 login attempts per IP per 5 minutes
    _rate_limit(f"login:{_client_ip(request)}", max_calls=10, window_seconds=300)

    username_input = data.get("username")
    password = data.get("password")

    if not username_input or not password:
        raise HTTPException(status_code=400, detail="Missing credentials")

    username = username_input.strip().lower()

    res = supabase.table("admins")\
        .select("*")\
        .ilike("username", username)\
        .execute()

    if not res.data:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    user = res.data[0]

    if not pwd_context.verify(password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = jwt.encode({
        "username": username,
        "exp": datetime.utcnow() + timedelta(hours=12)
    }, SECRET_KEY, algorithm=ALGORITHM)

    return {"token": token}

# =========================
# SETTINGS
# =========================



@app.get("/settings")
def settings_alias():
    res = supabase.table("admin_settings").select("*").limit(1).execute()
    return res.data[0] if res.data else {}

@app.get("/admin/settings")
def get_admin_settings(username: str = Depends(require_admin)):
    admin = supabase.table("admins").select("*").eq("username", username).execute().data

    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")

    admin_id = admin[0]["id"]

    res = supabase.table("admin_settings")\
        .select("*")\
        .eq("admin_id", admin_id)\
        .execute()

    return res.data[0] if res.data else {}    


@app.put("/admin/settings")
def update_settings(data: dict, username: str = Depends(require_admin)):
    # get admin id first
    admin = supabase.table("admins").select("*").eq("username", username).execute().data

    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")

    admin_id = admin[0]["id"]

    res = supabase.table("admin_settings")\
        .update(data)\
        .eq("admin_id", admin_id)\
        .execute()

    return {"success": True, "data": res.data}


# =========================
# STATS DASHBOARD
# =========================
@app.get("/admin/stats")
def stats(username: str = Depends(require_admin)):
    try:
        users = supabase.table(USER_TABLE).select("id, is_banned").execute().data or []
        comments = supabase.table("comments").select("id, toxicity").execute().data or []
        return {
            "quotes":    len(supabase.table("quotes").select("id").execute().data),
            "stories":   len(supabase.table("stories").select("id").execute().data),
            "blogs":     len(supabase.table("blogs").select("id").execute().data),
            "comments":  len(comments),
            "forumpost": len(supabase.table("forumpost").select("id").execute().data),
            "users":     len(users),
            "flagged_comments": sum(1 for c in comments if (c.get("toxicity") or 0) >= 0.7),
        }
    except Exception as e:
        logger.error(f"stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# =========================
# UPLOAD IMAGE
# =========================
def _save_image_bytes(file_bytes: bytes, ext: str) -> dict:
    """
    Shared helper: save image bytes to Supabase Storage (preferred) or local
    disk (fallback). Returns {"success": True, "url": ...}.
    """
    filename = f"{uuid.uuid4().hex}{ext}"
    content_type = mimetypes.guess_type(filename)[0] or "image/jpeg"

    # ── Primary: Supabase Storage (persistent) ──
    try:
        supabase.storage.from_(SUPABASE_BUCKET).upload(
            path=filename,
            file=file_bytes,
            file_options={"content-type": content_type, "upsert": "true"}
        )
        public_url = supabase.storage.from_(SUPABASE_BUCKET).get_public_url(filename)
        logger.info(f"Supabase Storage upload OK: {filename}")
        return {"success": True, "url": public_url}
    except Exception as e:
        logger.warning(f"Supabase Storage upload failed ({e}) — falling back to local disk")

    # ── Fallback: local disk (lost on redeploy, but better than nothing) ──
    path = os.path.join(UPLOAD_DIR, filename)
    try:
        with open(path, "wb") as buf:
            buf.write(file_bytes)
        logger.info(f"Local disk upload (fallback): {filename}")
        return {"success": True, "url": f"/uploads/{filename}"}
    except Exception as e:
        logger.error(f"Both upload paths failed: {e}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {e}")


async def _validate_and_read_upload(file: UploadFile) -> tuple[bytes, str]:
    """Validate extension and size; return (file_bytes, ext)."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
        )

    file_bytes = await file.read()

    if len(file_bytes) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Maximum allowed size is {MAX_UPLOAD_BYTES // (1024*1024)} MB."
        )

    return file_bytes, ext


@app.post("/upload-image")
async def upload(
    file: UploadFile = File(...),
    username: str = Depends(require_admin)
):
    """
    Admin upload to Supabase Storage (survives Render redeploys).
    Falls back to local disk if Storage bucket not yet configured.

    One-time Supabase setup:
      Dashboard → Storage → New bucket → Name: "images" → Public: ON
    """
    file_bytes, ext = await _validate_and_read_upload(file)
    return _save_image_bytes(file_bytes, ext)


@app.post("/upload-image-public")
async def upload_public(request: Request, file: UploadFile = File(...)):
    """
    Public (unauthenticated) image upload — used by the Story Submission form
    so individuals/organizations can attach a story image or logo before payment.
    Rate limited and validated identically to the admin upload endpoint.
    """
    _rate_limit(f"upload-public:{_client_ip(request)}", max_calls=10, window_seconds=600)
    file_bytes, ext = await _validate_and_read_upload(file)
    return _save_image_bytes(file_bytes, ext)
# =========================
# QUOTES
# =========================
@app.get("/quotes")
def get_quotes():
    try:
        res = supabase.table("quotes").select("*").execute()
        return res.data
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/quotes")
def create_quote(data: dict, username: str = Depends(require_admin)):
    res = supabase.table("quotes").insert(data).execute()
    return res.data


@app.put("/quotes/{quote_id}")
def update_quote(quote_id: int, data: dict, username: str = Depends(require_admin)):
    res = supabase.table("quotes").update(data).eq("id", quote_id).execute()
    return res.data


@app.delete("/quotes/{quote_id}")
def delete_quote(quote_id: int, username: str = Depends(require_admin)):
    supabase.table("quotes").delete().eq("id", quote_id).execute()
    return {"message": "Deleted"}


# =========================
# STORIES
# =========================
@app.get("/stories")
def get_stories(limit: int = 15, offset: int = 0):
    try:
        res = (
            supabase.table("stories")
            .select("*")
            .order("id", desc=True)
            .range(offset, offset + limit - 1)
            .execute()
        )
        return res.data
    except Exception as e:
        logger.error(f"get_stories: {e}")
        raise HTTPException(500, str(e))


@app.get("/stories/{story_id}")
def get_story(story_id: int):
    try:
        res = supabase.table("stories").select("*").eq("id", story_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Story not found")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"get_story {story_id}: {e}")
        raise HTTPException(500, str(e))


@app.post("/stories")
def create_story(data: dict, username: str = Depends(require_admin)):
    return supabase.table("stories").insert(data).execute().data

@app.put("/stories/{story_id}")
def update_story(story_id: int, data: dict, username: str = Depends(require_admin)):
    res = supabase.table("stories").update(data).eq("id", story_id).execute()
    if not res.data:
        raise HTTPException(status_code=404, detail="Story not found")
    return res.data

@app.delete("/stories/{story_id}")
def delete_story(story_id: int, username: str = Depends(require_admin)):
    supabase.table("stories").delete().eq("id", story_id).execute()
    logger.info(f"Story {story_id} deleted by admin")
    return {"message": "Story deleted", "id": story_id}

@app.get("/stories/count")
def stories_count():
    res = supabase.table("stories").select("id", count="exact").execute()
    return {"count": res.count}


# =========================
# BLOGS
# =========================
@app.get("/blogs")
def get_blogs(limit: int = 6, offset: int = 0):
    return (
        supabase.table("blogs")
        .select("*")
        .order("id", desc=True)
        .range(offset, offset + limit - 1)
        .execute()
        .data
    )


@app.get("/blogs/{blog_id}")
def get_blog(blog_id: int):
    try:
        res = supabase.table("blogs").select("*").eq("id", blog_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Blog not found")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"get_blog {blog_id}: {e}")
        raise HTTPException(500, str(e))


@app.post("/blogs")
def create_blog(data: dict, username: str = Depends(require_admin)):
    return supabase.table("blogs").insert(data).execute().data

@app.put("/blogs/{blog_id}")
def update_blog(blog_id: int, data: dict, username: str = Depends(require_admin)):
    res = supabase.table("blogs").update(data).eq("id", blog_id).execute()
    if not res.data:
        raise HTTPException(status_code=404, detail="Blog not found")
    return res.data

@app.delete("/blogs/{blog_id}")
def delete_blog(blog_id: int, username: str = Depends(require_admin)):
    supabase.table("blogs").delete().eq("id", blog_id).execute()
    logger.info(f"Blog {blog_id} deleted by admin")
    return {"message": "Blog deleted", "id": blog_id}


# =========================
# LIKES
# =========================
# Maps singular item_type → correct Supabase table name
_TYPE_TO_TABLE = {
    "quote":  "quotes",
    "story":  "stories",   # NOT "storys"
    "blog":   "blogs",
}

@app.post("/like/{item_type}/{item_id}")
def like(item_type: str, item_id: int):
    table = _TYPE_TO_TABLE.get(item_type)
    if not table:
        raise HTTPException(status_code=400, detail=f"Invalid item_type '{item_type}'. Must be quote, story, or blog.")
    try:
        rows = supabase.table(table).select("id, likes").eq("id", item_id).execute().data
        if not rows:
            raise HTTPException(status_code=404, detail=f"{item_type.capitalize()} #{item_id} not found")
        current = rows[0].get("likes") or 0
        new_val = current + 1
        supabase.table(table).update({"likes": new_val}).eq("id", item_id).execute()
        logger.info(f"Like: {table} id={item_id} → {new_val}")
        return {"likes": new_val}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"like {item_type}/{item_id}: {e}")
        raise HTTPException(status_code=500, detail="Could not update likes")


# =========================
# COMMENTS
# =========================
@app.get("/comments/{item_type}/{item_id}")
def get_comments(item_type: str, item_id: int):
    """Public — returns non-hidden comments only."""
    try:
        return (supabase.table("comments")
                .select("*")
                .eq("item_type", item_type)
                .eq("item_id", item_id)
                .neq("is_hidden", True)
                .execute().data)
    except Exception:
        # Fallback if is_hidden column doesn't exist yet
        return supabase.table("comments")\
            .select("*")\
            .eq("item_type", item_type)\
            .eq("item_id", item_id)\
            .execute().data


# ── SENTIMENT & TOXICITY HELPERS ──
_POS = {"love","great","amazing","wonderful","inspiring","beautiful","excellent",
        "fantastic","awesome","good","brilliant","perfect","happy","joy","thank","best"}
_NEG = {"hate","terrible","awful","bad","horrible","worst","ugly","boring",
        "disappointing","sad","angry","useless","poor","disgusting","failed","wrong"}
_FLAGGED = {"murder","kill","attack","abuse","rape","bomb","terrorist"}
_TOXIC   = {"hate","stupid","idiot","ugly","horrible","disgusting","awful",
            "terrible","worst","dumb","moron","loser","trash"}

def _sentiment(text: str) -> str:
    words = set(text.lower().split())
    pos, neg = len(words & _POS), len(words & _NEG)
    if pos > neg: return "positive"
    if neg > pos: return "negative"
    return "neutral"

def _toxicity(text: str) -> float:
    words = set(text.lower().split())
    f = len(words & _FLAGGED)
    t = len(words & _TOXIC)
    if f > 0: return min(0.70 + f * 0.10, 1.0)
    if t > 0: return min(0.30 + t * 0.10, 0.69)
    return 0.0


@app.post("/comments")
def add_comment(data: dict, request: Request, authorization: str = Header(None)):
    """
    Authenticated comment insert — requires a valid user JWT token.
    Rate limited per IP.
    """
    # Require user login
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="You must be logged in to comment. Please create an account or sign in.")
    user = _verify_user_token(authorization[7:])
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired session. Please sign in again.")
    if user.get("is_banned"):
        raise HTTPException(status_code=403, detail="Your account has been suspended. Please contact us if you believe this is an error.")

    # Rate limit: 15 comments per IP per 10 minutes
    _rate_limit(f"comment:{_client_ip(request)}", max_calls=15, window_seconds=600)

    text      = _validate_str(data.get("content"), "Comment content", max_len=1000)
    item_type = (data.get("item_type") or "").strip()
    item_id   = data.get("item_id")

    if not item_type or item_id is None:
        raise HTTPException(status_code=400, detail="item_type and item_id are required")
    if item_type not in ("quote", "story", "blog"):
        raise HTTPException(status_code=400, detail="item_type must be 'quote', 'story', or 'blog'")

    payload = {
        "username":  user["username"],
        "user_id":   user["id"],
        "content":   text,
        "item_type": item_type,
        "item_id":   int(item_id),
        "sentiment": _sentiment(text),
    }

    # Attempt 1: include toxicity score
    try:
        res = supabase.table("comments").insert({**payload, "toxicity": _toxicity(text)}).execute()
        if res.data:
            logger.info(f"Comment saved by user '{user['username']}' (with toxicity) id={res.data[0].get('id')}")
            return res.data
    except Exception as e:
        err = str(e).lower()
        if any(kw in err for kw in ["toxicity", "column", "schema", "undefined", "does not exist", "not found"]):
            logger.warning(f"toxicity column missing, retrying without it ({e})")
        else:
            logger.error(f"add_comment error: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to save comment: {e}")

    # Attempt 2: without toxicity
    try:
        res = supabase.table("comments").insert(payload).execute()
        if res.data:
            logger.info(f"Comment saved by user '{user['username']}' (no toxicity)")
            return res.data
        raise ValueError("Supabase returned empty data")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"add_comment retry error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to save comment: {e}")


@app.delete("/comments/{comment_id}")
def delete_comment(comment_id: int, username: str = Depends(require_admin)):
    """Delete a comment by ID. Requires admin Authorization header."""
    try:
        supabase.table("comments").delete().eq("id", comment_id).execute()
        logger.info(f"Admin '{username}' deleted comment {comment_id}")
        return {"message": "Comment deleted", "id": comment_id}
    except Exception as e:
        logger.error(f"delete_comment {comment_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete comment: {e}")


# =========================
# FORUM
# =========================
@app.get("/forum/posts")
def get_posts():
    return supabase.table("forumpost").select("*").execute().data


@app.post("/forum/post")
def create_post(data: dict, request: Request, authorization: str = Header(None)):
    """
    Authenticated forum post — requires a valid user JWT token.
    Rate limited per IP.
    """
    # Require user login
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="You must be logged in to post in the forum. Please create an account or sign in.")
    user = _verify_user_token(authorization[7:])
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired session. Please sign in again.")
    if user.get("is_banned"):
        raise HTTPException(status_code=403, detail="Your account has been suspended.")

    # Rate limit: 10 posts per IP per 10 minutes
    _rate_limit(f"forum:{_client_ip(request)}", max_calls=10, window_seconds=600)

    message = _validate_str(data.get("message"), "Message", max_len=500)

    # name comes from the authenticated user's username
    payload = {"name": user["username"], "message": message}

    try:
        res = supabase.table("forumpost").insert(payload).execute()
        logger.info(f"Forum post created by user '{user['username']}'")
        return res.data
    except Exception as e:
        logger.error(f"forum post insert error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to save post: {e}")


@app.put("/forum/posts/{post_id}")
def update_forum_post(post_id: int, data: dict, username: str = Depends(require_admin)):
    """Edit a forum post's name and/or message. Requires admin auth."""
    name    = (data.get("name")    or "").strip()
    message = (data.get("message") or "").strip()
    if not name and not message:
        raise HTTPException(status_code=400, detail="Provide at least name or message to update")
    payload = {}
    if name:    payload["name"]    = name
    if message: payload["message"] = message
    try:
        res = supabase.table("forumpost").update(payload).eq("id", post_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Forum post not found")
        logger.info(f"Forum post {post_id} updated by admin '{username}'")
        return res.data[0]
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"update_forum_post {post_id}: {e}")
        raise HTTPException(500, str(e))


@app.delete("/forum/posts/{post_id}")
def delete_forum_post(post_id: int, username: str = Depends(require_admin)):
    """Delete a forum post by ID. Requires admin auth."""
    try:
        supabase.table("forumpost").delete().eq("id", post_id).execute()
        logger.info(f"Forum post {post_id} deleted by admin '{username}'")
        return {"message": "Forum post deleted", "id": post_id}
    except Exception as e:
        logger.error(f"delete_forum_post {post_id}: {e}")
        raise HTTPException(500, str(e))


@app.post("/forum/posts/{post_id}/reply")
def reply_to_forum_post(post_id: int, data: dict, username: str = Depends(require_admin)):
    """Admin reply to a forum post — stored as a new forum post with @mention prefix."""
    message = (data.get("message") or "").strip()
    if not message:
        raise HTTPException(status_code=400, detail="Reply message is required")
    # Check original post exists
    original = supabase.table("forumpost").select("id, name").eq("id", post_id).execute()
    if not original.data:
        raise HTTPException(status_code=404, detail="Original post not found")
    original_name = original.data[0].get("name", "User")
    reply_message = f"@{original_name} — {message}"
    payload = {"name": f"Admin ({username})", "message": reply_message}
    try:
        res = supabase.table("forumpost").insert(payload).execute()
        logger.info(f"Admin '{username}' replied to forum post {post_id}")
        return res.data[0] if res.data else {"message": "Reply posted"}
    except Exception as e:
        logger.error(f"reply_to_forum_post {post_id}: {e}")
        raise HTTPException(500, str(e))


# =========================
# CONTACT
# =========================
@app.post("/contact/send")
def contact(data: dict, request: Request):
    """Public contact form — rate limited to 5 per IP per hour."""
    _rate_limit(f"contact:{_client_ip(request)}", max_calls=5, window_seconds=3600)
    name    = _validate_str(data.get("name"), "Name", max_len=100)
    email   = _validate_str(data.get("email"), "Email", max_len=200)
    message = _validate_str(data.get("message"), "Message", max_len=2000)
    # Basic email format check
    if "@" not in email or "." not in email:
        raise HTTPException(status_code=400, detail="Invalid email address")
    try:
        return supabase.table("contactmessage").insert({
            "name": name, "email": email, "message": message
        }).execute().data
    except Exception as e:
        logger.error(f"contact/send: {e}")
        raise HTTPException(status_code=500, detail="Failed to send message. Please try again.")


# =========================
# CHATBOT
# =========================
@app.post("/chatbot")
def chatbot(data: dict, request: Request):
    """
    Enhanced chatbot with 20+ command categories.
    All keyword matching is case-insensitive.
    """
    # Rate limit: 60 chatbot requests per IP per minute
    _rate_limit(f"chatbot:{_client_ip(request)}", max_calls=60, window_seconds=60)
    raw = (data.get("message") or "").strip()
    msg = raw.lower()

    if not msg:
        return {"reply": "Please type a message 😊 Try saying 'help' to see what I can do!"}

    # ── helpers ──
    def _quotes(limit=3):
        try:
            return supabase.table("quotes").select("*").limit(limit).execute().data or []
        except Exception:
            return []

    def _stories(limit=2):
        try:
            return supabase.table("stories").select("*").limit(limit).execute().data or []
        except Exception:
            return []

    def _blogs(limit=2):
        try:
            return supabase.table("blogs").select("*").limit(limit).execute().data or []
        except Exception:
            return []

    # =========================
    # GREETINGS
    # =========================
    if any(w in msg for w in ["hi", "hello", "hey", "good morning", "good afternoon", "good evening", "howdy", "greetings", "sup", "hola"]):
        import random
        greets = [
            "Hey there 👋 Welcome to QuoteMe ZW 💖 I'm here to inspire you! Ask me about quotes, stories, blogs, or anything else.",
            "Hello beautiful soul! 🌸 How can I inspire you today?",
            "Hey hey! 💖 Welcome to QuoteMe ZW — Zimbabwe's home of daily inspiration. What can I help you with?",
            "Hi there! 👋 Ready to get inspired? Ask me about quotes, stories, or our community forum!",
        ]
        return {"reply": random.choice(greets)}

    # =========================
    # GOODBYE
    # =========================
    if any(w in msg for w in ["bye", "goodbye", "see you", "later", "ciao", "take care"]):
        return {"reply": "Goodbye! 👋 Stay inspired and keep shining! 💖 Come back anytime — QuoteMe ZW is always here for you. ✨"}

    # =========================
    # THANK YOU
    # =========================
    if any(w in msg for w in ["thank", "thanks", "thank you", "cheers", "appreciate"]):
        return {"reply": "You're so welcome! 🌸 That's what we're here for. Keep spreading that positive energy! 💖"}

    # =========================
    # HOW ARE YOU
    # =========================
    if any(w in msg for w in ["how are you", "how r u", "how are u", "you okay", "you good"]):
        return {"reply": "I'm doing amazing, thank you for asking! 💖 I'm always energised when helping people find inspiration. How are YOU doing today? 😊"}

    # =========================
    # QUOTES
    # =========================
    if any(w in msg for w in ["quote", "quotes", "inspire me", "motivation", "motivate", "inspire", "uplift"]):
        rows = _quotes(3)
        if rows:
            sample = "\n\n".join([f"💬 \"{q['text']}\"\'\n   — {q.get('author','Unknown')}" for q in rows])
            return {"reply": f"Here are some inspiring quotes just for you ✨\n\n{sample}\n\nVisit our Quotes section for more! 💖"}
        return {"reply": "We post daily inspirational quotes! ✨ Check out our Quotes section on the homepage."}

    # =========================
    # RANDOM QUOTE
    # =========================
    if any(w in msg for w in ["random quote", "surprise me", "give me a quote", "quote of the day", "qotd"]):
        import random
        rows = _quotes(10)
        if rows:
            q = random.choice(rows)
            return {"reply": f"Here's one for you today ✨\n\n💬 \"{q['text']}\"\'\n— {q.get('author','QuoteMe ZW')}"}
        local = [
            "She believed she could, so she did. 🌸",
            "Your potential is endless. Keep going! 💪",
            "Queens don't compete — they collaborate. 👑",
            "The most powerful thing you can do is believe in yourself. ✨",
        ]
        import random
        return {"reply": "💬 " + random.choice(local)}

    # =========================
    # STORIES
    # =========================
    if any(w in msg for w in ["story", "stories", "empowerment", "women", "real stories", "success story"]):
        rows = _stories(2)
        if rows:
            sample = "\n\n".join([f"📖 *{s['title']}*\n{s['content'][:100]}..." for s in rows])
            return {"reply": f"Here are some powerful empowerment stories 💖\n\n{sample}\n\nClick \'Read More\' on any story for the full version!"}
        return {"reply": "We share real women empowerment stories! 💖 Check the Stories section on our homepage."}

    # =========================
    # BLOGS
    # =========================
    if any(w in msg for w in ["blog", "blogs", "article", "read", "post", "posts"]):
        rows = _blogs(2)
        if rows:
            sample = "\n\n".join([f"📰 *{b['title']}*\n{b['content'][:100]}..." for b in rows])
            return {"reply": f"Here are some of our latest blogs 🚀\n\n{sample}\n\nHead to our Blog section for more!"}
        return {"reply": "Check our Blog section for motivational articles and tips! 🚀"}

    # =========================
    # FORUM
    # =========================
    if any(w in msg for w in ["forum", "community", "discussion", "chat", "talk", "ask", "question", "connect"]):
        return {
            "reply": (
                "Our Community Forum is the best place to connect! 🗣️\n\n"
                "You can:\n"
                "💬 Share general thoughts\n"
                "📖 Discuss stories\n"
                "❓ Ask questions\n"
                "💡 Leave feedback\n\n"
                "Scroll down to the Forum section to join the conversation!"
            )
        }

    # =========================
    # DONATE / SUPPORT US
    # =========================
    if any(w in msg for w in ["donate", "donation", "support", "contribute", "fund", "help us", "paypal"]):
        return {
            "reply": (
                "Thank you so much for wanting to support us! 💖\n\n"
                "Every donation helps us:\n"
                "💬 Create more inspiring quotes\n"
                "📖 Share more empowerment stories\n"
                "🚀 Grow our community\n\n"
                "Visit our Donate section on the homepage to contribute. Even $1 makes a difference! 🌸"
            )
        }

    # =========================
    # ABOUT
    # =========================
    if any(w in msg for w in ["about", "what is this", "who are you", "what is quoteme", "tell me about", "quoteme zw", "mission", "vision"]):
        return {
            "reply": (
                "QuoteMe ZW is Zimbabwe's home of daily inspiration! 🇿🇼💖\n\n"
                "We are a platform dedicated to:\n"
                "🌟 Empowering women and youth\n"
                "💬 Sharing daily inspirational quotes\n"
                "📖 Celebrating real success stories\n"
                "📰 Publishing motivational blogs\n"
                "🤝 Building a supportive community\n\n"
                "Founded with love and a mission to make inspiration accessible to everyone in Zimbabwe and beyond. ✨"
            )
        }

    # =========================
    # FOUNDER / TEAM
    # =========================
    if any(w in msg for w in ["founder", "team", "who made", "who created", "creator", "owner"]):
        return {
            "reply": (
                "QuoteMe ZW was founded by a passionate visionary who believes every woman and young person "
                "deserves access to daily inspiration and a community that lifts them up. 💖\n\n"
                "Our small but dedicated team curates every quote, story, and blog with love and purpose. 🌸\n\n"
                "Want to know more? Visit our About section or reach out via our Contact form!"
            )
        }

    # =========================
    # CONTACT / SUPPORT
    # =========================
    if any(w in msg for w in ["contact", "email", "reach", "reach out", "message us", "get in touch", "collaborate"]):
        return {
            "reply": (
                "We'd love to hear from you! 📩\n\n"
                "You can reach us via:\n"
                "📝 The Contact form on the homepage\n"
                "📧 Email: support@quotemezw.com\n"
                "📸 Instagram: @quoteme_zw\n\n"
                "Whether it's a collaboration, feedback, or just to say hi — we're always happy to connect! 💖"
            )
        }

    # =========================
    # INSTAGRAM / SOCIAL MEDIA
    # =========================
    if any(w in msg for w in ["instagram", "social", "social media", "follow", "ig", "insta"]):
        return {
            "reply": (
                "Follow us on Instagram for daily inspiration! 📸\n\n"
                "👉 @quoteme_zw\n\n"
                "We post:\n"
                "✨ Daily motivational quotes\n"
                "💖 Empowerment content\n"
                "🌸 Behind-the-scenes updates\n\n"
                "See you there! 💕"
            )
        }

    # =========================
    # DARK MODE
    # =========================
    if any(w in msg for w in ["dark mode", "dark theme", "night mode", "light mode"]):
        return {"reply": "You can toggle between dark and light mode using the 🌙 button in the top navigation bar! Your preference is saved automatically. 🌙✨"}

    # =========================
    # LIKES / COMMENTS
    # =========================
    if any(w in msg for w in ["like", "comment", "react", "interaction"]):
        return {
            "reply": (
                "Great question! 💖\n\n"
                "On every quote, story, and blog you can:\n"
                "❤️ Like it to show your love\n"
                "💬 Leave a comment\n"
                "😊 Comments even show a positivity score!\n\n"
                "Try it on your favourite quote now! ✨"
            )
        }

    # =========================
    # ZIMBABWE
    # =========================
    if any(w in msg for w in ["zimbabwe", "zim", "harare", "bulawayo", "african", "africa"]):
        return {
            "reply": (
                "QuoteMe ZW is proudly Zimbabwean! 🇿🇼✨\n\n"
                "We celebrate the strength, resilience, and beauty of Zimbabwean women and youth. "
                "Our content is curated with our community in mind — relatable, empowering, and real. 💖\n\n"
                "Zimbabwe rises through its people! 🌟"
            )
        }

    # =========================
    # AFFIRMATION / POSITIVITY
    # =========================
    if any(w in msg for w in ["affirmation", "positive", "positivity", "feel good", "cheer up", "sad", "down", "depressed", "struggling"]):
        import random
        affirmations = [
            "You are stronger than you think, braver than you feel, and more loved than you know. 💖",
            "Every day is a new beginning. Take a deep breath and start again. 🌸",
            "You are enough. You have always been enough. ✨",
            "Your story isn't over yet — the best chapters are still ahead! 📖",
            "Difficult roads often lead to beautiful destinations. Keep going! 🌟",
        ]
        return {"reply": "Here's a little love from QuoteMe ZW 💖\n\n🌸 " + random.choice(affirmations) + "\n\nYou've got this! 💪"}

    # =========================
    # ADMIN HELP
    # =========================
    if "admin" in msg:
        return {"reply": "The admin panel is available at /admin 🔐 Only authorised team members can log in. If you need access, please contact us via the Contact form."}

    # =========================
    # HELP / COMMANDS
    # =========================
    if any(w in msg for w in ["help", "what can you do", "commands", "menu", "options", "what do you do"]):
        return {
            "reply": (
                "Here's everything I can help you with! 💖\n\n"
                "✨ *Quotes* — Get inspiring quotes\n"
                "🎲 *Random quote* — Surprise quote just for you\n"
                "📖 *Stories* — Women empowerment stories\n"
                "📰 *Blogs* — Motivational articles\n"
                "🗣️ *Forum* — Join the community discussion\n"
                "💖 *Donate* — Support our mission\n"
                "ℹ️ *About* — Learn about QuoteMe ZW\n"
                "🌸 *Affirmation* — Need a pick-me-up?\n"
                "📩 *Contact* — Get in touch with us\n"
                "📸 *Instagram* — Find us on social media\n"
                "🇿🇼 *Zimbabwe* — Our Zimbabwean pride!\n\n"
                "Just type any of the above or ask me anything! 😊"
            )
        }

    # =========================
    # FALLBACK
    # =========================
    import random
    fallbacks = [
        f"Hmm, I'm not sure about \"{raw}\" yet 🤔\n\nTry asking about quotes, stories, blogs, our forum, or say \'help\' to see all my commands! 😊",
        f"I didn't quite catch that! 🤔 Try saying \'help\' to see everything I can do. Or ask me for a \'random quote\'! ✨",
        "I'm still learning! 🌱 Try asking about quotes, stories, or say \'help\' for a full list of things I can help you with! 💖",
    ]
    return {"reply": random.choice(fallbacks)}


# =========================================
# SITE USER ACCOUNTS
# Register / Login / Profile
# =========================================
USER_TABLE = "site_users"

EMAIL_RE = re.compile(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')
USERNAME_RE = re.compile(r'^[a-zA-Z0-9_]{3,40}$')


@app.post("/users/register")
def user_register(data: dict, request: Request):
    """
    Public — create a new site user account.
    Rate limited to 5 registrations per IP per hour.
    """
    _rate_limit(f"register:{_client_ip(request)}", max_calls=5, window_seconds=3600)

    username = _validate_str(data.get("username"), "Username", max_len=40)
    email    = _validate_str(data.get("email"),    "Email",    max_len=200)
    password = (data.get("password") or "").strip()

    # Validations
    if not USERNAME_RE.match(username):
        raise HTTPException(status_code=400, detail="Username must be 3–40 characters and contain only letters, numbers, or underscores.")
    if not EMAIL_RE.match(email):
        raise HTTPException(status_code=400, detail="Please enter a valid email address.")
    if len(password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters.")
    if len(password) > 72:
        password = password[:72]

    email = email.lower()

    # Check uniqueness
    try:
        existing_user  = supabase.table(USER_TABLE).select("id").eq("username", username).execute().data
        existing_email = supabase.table(USER_TABLE).select("id").eq("email", email).execute().data
    except Exception as e:
        logger.error(f"user_register check: {e}")
        raise HTTPException(status_code=500, detail="Could not verify account details. Please try again.")

    if existing_user:
        raise HTTPException(status_code=409, detail="That username is already taken. Please choose another.")
    if existing_email:
        raise HTTPException(status_code=409, detail="An account with that email address already exists. Please sign in.")

    # Hash password and create user
    hashed = pwd_context.hash(password)
    try:
        res = supabase.table(USER_TABLE).insert({
            "username":      username,
            "email":         email,
            "password_hash": hashed,
            "is_banned":     0,
        }).execute()
        if not res.data:
            raise ValueError("Empty response from Supabase")
        user = res.data[0]
        token = _make_user_token(user)
        logger.info(f"New site user registered: '{username}' ({email})")
        return {
            "success":  True,
            "token":    token,
            "username": user["username"],
            "email":    user["email"],
            "id":       user["id"],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"user_register insert: {e}")
        raise HTTPException(status_code=500, detail="Failed to create account. Please try again.")


@app.post("/users/login")
def user_login(data: dict, request: Request):
    """
    Public — authenticate a site user by email + password.
    Rate limited to 10 attempts per IP per 5 minutes.
    """
    _rate_limit(f"userlogin:{_client_ip(request)}", max_calls=10, window_seconds=300)

    email    = (data.get("email")    or "").strip().lower()
    password = (data.get("password") or "").strip()

    if not email or not password:
        raise HTTPException(status_code=400, detail="Email and password are required.")

    try:
        res = supabase.table(USER_TABLE).select("*").eq("email", email).execute()
    except Exception as e:
        logger.error(f"user_login lookup: {e}")
        raise HTTPException(status_code=500, detail="Login failed. Please try again.")

    if not res.data:
        raise HTTPException(status_code=401, detail="No account found with that email address.")

    user = res.data[0]

    # Check ban before verifying password (fail fast)
    if user.get("is_banned"):
        reason = user.get("ban_reason") or "your account has been suspended"
        raise HTTPException(status_code=403, detail=f"Access denied — {reason}. Please contact us if you believe this is an error.")

    # Verify password
    try:
        if not pwd_context.verify(password[:72], user["password_hash"]):
            raise HTTPException(status_code=401, detail="Incorrect password. Please try again.")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"user_login verify: {e}")
        raise HTTPException(status_code=401, detail="Incorrect password. Please try again.")

    # Update last_seen
    try:
        supabase.table(USER_TABLE).update({"last_seen": datetime.utcnow().isoformat()}).eq("id", user["id"]).execute()
    except Exception:
        pass  # non-fatal

    token = _make_user_token(user)
    logger.info(f"Site user logged in: '{user['username']}'")
    return {
        "success":  True,
        "token":    token,
        "username": user["username"],
        "email":    user["email"],
        "id":       user["id"],
    }


@app.get("/users/me")
def user_me(authorization: str = Header(...)):
    """Return the current user's profile from their JWT."""
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    user = _verify_user_token(authorization[7:])
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return user


# ── ADMIN: manage site users ──
@app.get("/admin/users")
def admin_list_users(username: str = Depends(require_admin), search: str = None):
    """Admin — list all registered site users."""
    try:
        res = supabase.table(USER_TABLE).select("id, username, email, is_banned, ban_reason, created_at, last_seen").order("id", desc=True).execute()
        rows = res.data or []
        if search:
            s = search.lower().strip()
            rows = [r for r in rows if s in (r.get("username") or "").lower() or s in (r.get("email") or "").lower()]
        return rows
    except Exception as e:
        logger.error(f"admin_list_users: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/admin/users/{user_id}/ban")
def admin_ban_user(user_id: int, data: dict = None, username: str = Depends(require_admin)):
    """Admin — ban a site user."""
    data = data or {}
    reason = _strip_html((data.get("reason") or "Account suspended by admin"))[:300]
    try:
        res = supabase.table(USER_TABLE).update({"is_banned": 1, "ban_reason": reason}).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="User not found")
        logger.info(f"Admin '{username}' banned user {user_id}: {reason}")
        return {"success": True, "user_id": user_id, "banned": True}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"admin_ban_user {user_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/admin/users/{user_id}/unban")
def admin_unban_user(user_id: int, username: str = Depends(require_admin)):
    """Admin — lift a ban on a site user."""
    try:
        res = supabase.table(USER_TABLE).update({"is_banned": 0, "ban_reason": None}).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="User not found")
        logger.info(f"Admin '{username}' unbanned user {user_id}")
        return {"success": True, "user_id": user_id, "banned": False}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"admin_unban_user {user_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/admin/users/{user_id}")
def admin_delete_user(user_id: int, username: str = Depends(require_admin)):
    """Admin — permanently delete a site user account."""
    try:
        supabase.table(USER_TABLE).delete().eq("id", user_id).execute()
        logger.info(f"Admin '{username}' deleted user {user_id}")
        return {"success": True, "user_id": user_id}
    except Exception as e:
        logger.error(f"admin_delete_user {user_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# =========================================
# EXTENDED USER MANAGEMENT
# =========================================

@app.post("/users/change-password")
def user_change_password(data: dict, authorization: str = Header(...)):
    """Authenticated user — change own password."""
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    user = _verify_user_token(authorization[7:])
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    current_pw  = (data.get("current_password") or "").strip()
    new_pw      = (data.get("new_password")     or "").strip()

    if not current_pw or not new_pw:
        raise HTTPException(status_code=400, detail="Both current and new password are required.")
    if len(new_pw) < 6:
        raise HTTPException(status_code=400, detail="New password must be at least 6 characters.")

    try:
        row = supabase.table(USER_TABLE).select("password_hash").eq("id", user["id"]).execute()
    except Exception as e:
        raise HTTPException(status_code=500, detail="Could not verify credentials.")

    if not row.data:
        raise HTTPException(status_code=404, detail="User not found.")
    if not pwd_context.verify(current_pw[:72], row.data[0]["password_hash"]):
        raise HTTPException(status_code=401, detail="Current password is incorrect.")

    hashed = pwd_context.hash(new_pw[:72])
    supabase.table(USER_TABLE).update({"password_hash": hashed}).eq("id", user["id"]).execute()
    logger.info(f"User '{user['username']}' changed their password")
    return {"success": True}


@app.post("/admin/users/{user_id}/reset-password")
def admin_reset_password(user_id: int, data: dict, username: str = Depends(require_admin)):
    """Admin — reset a user's password to a provided value."""
    new_pw = (data.get("new_password") or "").strip()
    if not new_pw or len(new_pw) < 6:
        raise HTTPException(status_code=400, detail="New password must be at least 6 characters.")
    hashed = pwd_context.hash(new_pw[:72])
    try:
        res = supabase.table(USER_TABLE).update({"password_hash": hashed}).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="User not found")
        logger.info(f"Admin '{username}' reset password for user {user_id}")
        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/admin/users/{user_id}/promote")
def admin_promote_user(user_id: int, data: dict, username: str = Depends(require_admin)):
    """Admin — set a user's role (user / moderator / admin)."""
    role = (data.get("role") or "").strip().lower()
    if role not in ("user", "moderator", "admin"):
        raise HTTPException(status_code=400, detail="Role must be 'user', 'moderator', or 'admin'.")
    try:
        res = supabase.table(USER_TABLE).update({"role": role}).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="User not found")
        logger.info(f"Admin '{username}' set user {user_id} role to '{role}'")
        return {"success": True, "role": role}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/admin/users/{user_id}/suspend")
def admin_suspend_user(user_id: int, data: dict = None, username: str = Depends(require_admin)):
    """Admin — temporarily suspend a user (same flag as ban, but different label)."""
    data = data or {}
    reason = _strip_html((data.get("reason") or "Account temporarily suspended"))[:300]
    try:
        res = supabase.table(USER_TABLE).update({
            "is_banned": 1,
            "ban_reason": reason,
        }).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="User not found")
        logger.info(f"Admin '{username}' suspended user {user_id}: {reason}")
        return {"success": True, "user_id": user_id, "suspended": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/admin/users/{user_id}/reactivate")
def admin_reactivate_user(user_id: int, username: str = Depends(require_admin)):
    """Admin — reactivate a suspended/banned user."""
    try:
        res = supabase.table(USER_TABLE).update({
            "is_banned":  0,
            "ban_reason": None,
        }).eq("id", user_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="User not found")
        logger.info(f"Admin '{username}' reactivated user {user_id}")
        return {"success": True, "user_id": user_id}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Extended user stats ──
@app.get("/admin/users/stats")
def admin_user_stats(username: str = Depends(require_admin)):
    """Admin — aggregate stats about registered users."""
    try:
        rows = supabase.table(USER_TABLE).select("id, is_banned, role, created_at").execute().data or []
        now = datetime.utcnow()
        week_ago = now - timedelta(days=7)
        total   = len(rows)
        active  = sum(1 for r in rows if not r.get("is_banned"))
        banned  = sum(1 for r in rows if r.get("is_banned"))
        mods    = sum(1 for r in rows if r.get("role") == "moderator")
        new_7d  = sum(1 for r in rows if r.get("created_at") and
                      datetime.fromisoformat(str(r["created_at"]).replace("Z","")) >= week_ago)
        return {
            "total":   total,
            "active":  active,
            "banned":  banned,
            "moderators": mods,
            "new_7d":  new_7d,
        }
    except Exception as e:
        logger.error(f"admin_user_stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# =========================================
# EXTENDED COMMENT MODERATION
# =========================================

@app.get("/admin/comments")
def admin_get_all_comments(
    username: str = Depends(require_admin),
    sentiment_filter: str = None,
    search: str = None,
    item_type: str = None,
    show_hidden: str = "all",   # all | visible | hidden
):
    """
    Admin — retrieve all comments with optional filters.
    sentiment_filter: positive | neutral | negative | toxic | flagged
    show_hidden: all | visible | hidden
    """
    try:
        rows = supabase.table("comments").select("*").order("id", desc=True).execute().data or []
    except Exception as e:
        logger.error(f"admin_get_all_comments: {e}")
        raise HTTPException(status_code=500, detail=str(e))

    # Filter by hidden status
    if show_hidden == "visible":
        rows = [r for r in rows if not r.get("is_hidden")]
    elif show_hidden == "hidden":
        rows = [r for r in rows if r.get("is_hidden")]

    # Filter by item_type
    if item_type and item_type in ("quote", "story", "blog"):
        rows = [r for r in rows if r.get("item_type") == item_type]

    # Filter by sentiment / toxicity bucket
    if sentiment_filter:
        sf = sentiment_filter.lower()
        if sf == "positive":
            rows = [r for r in rows if r.get("sentiment") == "positive"]
        elif sf == "neutral":
            rows = [r for r in rows if r.get("sentiment") == "neutral"]
        elif sf == "negative":
            rows = [r for r in rows if r.get("sentiment") == "negative"]
        elif sf == "toxic":
            rows = [r for r in rows if (r.get("toxicity") or 0) >= 0.4]
        elif sf == "flagged":
            rows = [r for r in rows if (r.get("toxicity") or 0) >= 0.7]

    # Text search
    if search:
        s = search.lower().strip()
        rows = [r for r in rows if
                s in (r.get("content") or "").lower() or
                s in (r.get("username") or "").lower()]

    return rows


@app.post("/admin/comments/{comment_id}/hide")
def admin_hide_comment(comment_id: int, username: str = Depends(require_admin)):
    """Admin — hide a comment from public view (soft delete)."""
    try:
        res = supabase.table("comments").update({"is_hidden": True}).eq("id", comment_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Comment not found")
        logger.info(f"Admin '{username}' hid comment {comment_id}")
        return {"success": True, "comment_id": comment_id, "hidden": True}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"admin_hide_comment {comment_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/admin/comments/{comment_id}/restore")
def admin_restore_comment(comment_id: int, username: str = Depends(require_admin)):
    """Admin — restore a previously hidden comment."""
    try:
        res = supabase.table("comments").update({"is_hidden": False}).eq("id", comment_id).execute()
        if not res.data:
            raise HTTPException(status_code=404, detail="Comment not found")
        logger.info(f"Admin '{username}' restored comment {comment_id}")
        return {"success": True, "comment_id": comment_id, "hidden": False}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"admin_restore_comment {comment_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/admin/comments/stats")
def admin_comment_stats(username: str = Depends(require_admin)):
    """Admin — aggregate comment moderation stats."""
    try:
        rows = supabase.table("comments").select("*").execute().data or []
    except Exception as e:
        logger.error(f"admin_comment_stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

    total    = len(rows)
    positive = sum(1 for r in rows if r.get("sentiment") == "positive")
    neutral  = sum(1 for r in rows if r.get("sentiment") == "neutral")
    negative = sum(1 for r in rows if r.get("sentiment") == "negative")
    toxic    = sum(1 for r in rows if (r.get("toxicity") or 0) >= 0.4)
    flagged  = sum(1 for r in rows if (r.get("toxicity") or 0) >= 0.7)
    hidden   = sum(1 for r in rows if r.get("is_hidden"))

    return {
        "total":    total,
        "positive": positive,
        "neutral":  neutral,
        "negative": negative,
        "toxic":    toxic,
        "flagged":  flagged,
        "hidden":   hidden,
    }


# Override the public comments endpoint to exclude hidden comments
@app.get("/comments/{item_type}/{item_id}/public")
def get_comments_public(item_type: str, item_id: int):
    """Public — returns only non-hidden comments."""
    return (supabase.table("comments")
            .select("*")
            .eq("item_type", item_type)
            .eq("item_id", item_id)
            .neq("is_hidden", True)
            .execute().data)


# Extended stats including users
@app.get("/admin/stats/extended")
def stats_extended(username: str = Depends(require_admin)):
    """Extended stats including user counts."""
    try:
        users = supabase.table(USER_TABLE).select("id, is_banned").execute().data or []
        comments = supabase.table("comments").select("id, toxicity, is_hidden").execute().data or []
        return {
            "quotes":    len(supabase.table("quotes").select("id").execute().data),
            "stories":   len(supabase.table("stories").select("id").execute().data),
            "blogs":     len(supabase.table("blogs").select("id").execute().data),
            "comments":  len(comments),
            "forumpost": len(supabase.table("forumpost").select("id").execute().data),
            "users":     len(users),
            "users_active": sum(1 for u in users if not u.get("is_banned")),
            "users_banned": sum(1 for u in users if u.get("is_banned")),
            "flagged_comments": sum(1 for c in comments if (c.get("toxicity") or 0) >= 0.7),
            "hidden_comments":  sum(1 for c in comments if c.get("is_hidden")),
        }
    except Exception as e:
        logger.error(f"stats_extended: {e}")
        raise HTTPException(status_code=500, detail=str(e))
